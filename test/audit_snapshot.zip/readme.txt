Informacje na temat treści i poprawnej interpretacji danych w raporcie kontroli w formacie CSV 
można znaleźć pod następującym adresem:
http://ibm.biz/LMT_snapshot_content